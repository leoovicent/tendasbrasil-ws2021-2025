<?php
    // exit if accessed directly
    if( ! defined( 'ABSPATH' ) ) exit;

    die("It Works!");